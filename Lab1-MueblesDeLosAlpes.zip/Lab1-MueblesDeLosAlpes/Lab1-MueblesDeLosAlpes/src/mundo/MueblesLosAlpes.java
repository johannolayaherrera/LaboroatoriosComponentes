/**
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * $Id: MueblesLosAlpes.java,v 1.1 Exp $
 * Universidad de los Andes (Bogotá - Colombia)
 * Departamento de Ingeniería de Sistemas y Computación
 * Licenciado bajo el esquema Academic Free License version 2.1
 *
 * Ejercicio: Taller 1 - anotaciones
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 */
package mundo;

import anotaciones.Cargar;
import anotaciones.PostConstructor;

/**
 * Punto de entrada a la capa de logica de negocio
 */
public class MueblesLosAlpes {

    /**
     * Manajador de la lista de muebles
     */
    @Cargar
    private ManejadorMuebles muebles;

    /**
     * Manejador de la lista de vendedores
     */
    @Cargar
    private ManejadorVendedores vendedores;

    public MueblesLosAlpes() {
        System.out.println("Constructor ");
    }

    /**
     * Retorna el manejador de la lista de muebles
     * @return
     */
    public ManejadorMuebles getManejadorMuebles() {
        return muebles;
    }

    /**
     * Retorna el manejador de la lista de vendedores
     * @return
     */
    public ManejadorVendedores getManejadorVendedores() {
        return vendedores;
    }

    /**
     * Metodo de prueba de la anotación PreConstructor
     */
    public static void antesDelConstructor(){
        System.out.println("Antes del constructor 1");
    }

    /**
     * Metodo de prueba de la anotación PostConstructor
     */
    @PostConstructor
    public void despuesDelConstructor(){
        System.out.println("Despues del constructor");
    }
    
}
